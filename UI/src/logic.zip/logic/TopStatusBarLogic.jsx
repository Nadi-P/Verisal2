import { useState, useEffect, useCallback, useMemo } from 'react';

export function useTopStatusBarLogic(metadata, columns, onApplyColumns, onToggleColumns, onRunComparison) {
  // --- Comparison State ---
  const [compData, setCompData] = useState({
    m1: '', y1: '',
    m2: '', y2: ''
  });

  // Default values based on metadata range
  useEffect(() => {
    if (metadata.minMonth && metadata.maxMonth) {
      setCompData({
        m1: metadata.maxMonth, y1: metadata.maxYear,
        m2: metadata.minMonth, y2: metadata.minYear
      });
    }
  }, [metadata]);

  const handleCompChange = (e) => {
    const { name, value } = e.target;
    // Only allow digits
    const cleanValue = value.replace(/\D/g, '');
    setCompData(prev => ({ ...prev, [name]: cleanValue }));
  };

  const isComparisonValid = useMemo(() => {
    const { m1, y1, m2, y2 } = compData;
    if (!m1 || !y1 || !m2 || !y2) return false;
    
    // Check if identical
    if (m1 === m2 && y1 === y2) return false;

    // Range Check (using metadata from backend)
    const valM1 = parseInt(m1);
    const valM2 = parseInt(m2);
    if (valM1 < 1 || valM1 > 12 || valM2 < 1 || valM2 > 12) return false;
    
    return true;
  }, [compData]);

  const handleRunComparison = () => {
    if (isComparisonValid) {
      onRunComparison({
        m1: parseInt(compData.m1),
        y1: parseInt(compData.y1),
        m2: parseInt(compData.m2),
        y2: parseInt(compData.y2)
      });
    }
  };

  // --- Columns Logic (Merged) ---
  const [localColumns, setLocalColumns] = useState([]);

  useEffect(() => {
    if (columns) {
        setLocalColumns(columns.map(c => ({ ...c })));
    }
    }, [columns]);

  const handleToggleVisible = useCallback((index) => {
    setLocalColumns(prev => {
      const next = [...prev];
      next[index] = { ...next[index], visible: !next[index].visible };
      if (!next[index].visible) next[index].pinned = false;
      return next;
    });
  }, []);

  const handleApplyColumns = () => {
    const pinned = localColumns.filter(c => c.pinned);
    const unpinned = localColumns.filter(c => !c.pinned);
    onApplyColumns([...pinned, ...unpinned]);
  };

  return {
    compData,
    handleCompChange,
    isComparisonValid,
    handleRunComparison,
    localColumns,
    handleToggleVisible,
    handleApplyColumns
  };
}