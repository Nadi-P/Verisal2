import { useState, useMemo, useRef, useCallback } from 'react';

export const DARK_THEME = {
  pageBg: '#1a1b1e',
  cellBg: '#25262b',
  headerBg: 'hsl(230, 9%, 5%)',
  text: '#d4d5db',
  headerText: '#9ba3af',
  border: '#3a3b40',
  accent: '#4b87ff',
  selection: 'rgba(75, 135, 255, 0.2)',
};

export function useAppState() {
  const [rowData, setRowData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [metadata, setMetadata] = useState({
    companyName: '',
    dateRange: '',
    reportTitle: 'נא לבחור דוח'
  });

  const [zoom, setZoom] = useState(100);

  return { rowData, setRowData, isLoading, setIsLoading, metadata, setMetadata, zoom, setZoom };
}

export function useSideMenu(setTableData, setIsLoading, setMetadata) {
  const [sharedSelectedItem, setSharedSelectedItem] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(null);

  const toggleDropdown = useCallback((title) => {
    setOpenDropdown((prev) => (prev === title ? null : title));
  }, []);

  const handleSelect = useCallback(async (categoryTitle, itemData) => {
    setSharedSelectedItem({ category: categoryTitle, item: itemData.file_name });
    setIsLoading(true);

    try {
      const response = await fetch(`http://localhost:8000/api/get_report?report_name=${itemData.file_name}`);
      const result = await response.json();

      if (result.status === "success") {
        setTableData(result.data);
        
        // Update Metadata from backend attributes
        setMetadata({
          companyName: result.metadata.company_name,
          dateRange: `${result.metadata.min_month}/${result.metadata.min_year} - ${result.metadata.max_month}/${result.metadata.max_year}`,
          reportTitle: itemData.display_title
        });
      }
    } catch (error) {
      console.error("Error fetching report:", error);
    } finally {
      setIsLoading(false);
    }
  }, [setTableData, setIsLoading, setMetadata]);

  return { sharedSelectedItem, openDropdown, toggleDropdown, handleSelect };
}

export function useAuditTable(rowData) {
  const [selection, setSelection] = useState(null);
  const [isSelecting, setIsSelecting] = useState(false);
  const tableContainerRef = useRef(null);

  // Freezes the first column of the dataset automatically
  const frozenColumns = useMemo(() => {
    return [Object.keys(rowData[0] || {})[0]];
  }, [rowData]);

  // Build column definitions from row keys
  const columns = useMemo(() => {
    if (!rowData || rowData.length === 0) return [];
    return Object.keys(rowData[0]).map((key) => ({
      accessorFn: (row) => row[key],
      id: key,
      header: key,
      size: 150,
    }));
  }, [rowData]);

  const handleMouseDown = useCallback((r, c) => {
    setIsSelecting(true);
    setSelection({ start: { r, c }, end: { r, c } });
  }, []);

  const handleMouseEnter = useCallback((r, c) => {
    if (isSelecting) {
      setSelection((prev) => ({ ...prev, end: { r, c } }));
    }
  }, [isSelecting]);

  const handleMouseUp = useCallback(() => {
    setIsSelecting(false);
  }, []);

  const isCellSelected = useCallback((r, c) => {
    if (!selection) return false;
    const { start, end } = selection;
    const minR = Math.min(start.r, end.r), maxR = Math.max(start.r, end.r);
    const minC = Math.min(start.c, end.c), maxC = Math.max(start.c, end.c);
    return r >= minR && r <= maxR && c >= minC && c <= maxC;
  }, [selection]);

  /**
   * Returns sticky CSS styles for frozen columns.
   * @param {string} columnId
   * @param {boolean} isHeader
   */
  const getStickyStyles = useCallback((columnId, isHeader = false) => {
    if (!frozenColumns.includes(columnId)) return {};
    return {
      position: 'sticky',
      right: 0,
      zIndex: isHeader ? 3 : 2,
      backgroundColor: isHeader ? DARK_THEME.headerBg : DARK_THEME.cellBg,
      boxShadow:
        'inset 1px 0 0 0 ' + DARK_THEME.border + ', -2px 0 5px rgba(0,0,0,0.3)',
    };
  }, [frozenColumns]);

  const selectionStats = useMemo(() => {
    if (!selection || !rowData.length) return null;

    const { start, end } = selection;
    const minR = Math.min(start.r, end.r), maxR = Math.max(start.r, end.r);
    const minC = Math.min(start.c, end.c), maxC = Math.max(start.c, end.c);

    const selectedValues = [];
    let lastColName = "";

    // Extract values from rowData based on selection coordinates
    // Assuming 'columns' are available or we map keys from rowData
    const keys = Object.keys(rowData[0]); 

    for (let r = minR; r <= maxR; r++) {
      for (let c = minC; c <= maxC; c++) {
        const val = rowData[r][keys[c]];
        selectedValues.push(val);
        lastColName = keys[c];
      }
    }

    const count = selectedValues.length;
    const numericValues = selectedValues
      .map(v => parseFloat(v))
      .filter(v => !isNaN(v));

    if (count === 1) {
      return { type: 'single', label: lastColName, value: selectedValues[0] };
    }

    if (numericValues.length > 0) {
      const sum = numericValues.reduce((a, b) => a + b, 0);
      const avg = sum / numericValues.length;
      let ratio = null;

      if (numericValues.length === 2) {
        const sorted = [...numericValues].sort((a, b) => a - b);
        ratio = (sorted[1] !== 0) ? (sorted[0] / sorted[1]) * 100 : 0;
      }

      return {
        type: 'multi',
        sum: sum.toLocaleString(),
        avg: avg.toFixed(2),
        count: count,
        ratio: ratio !== null ? ratio.toFixed(2) : null
      };
    }

    return { type: 'multi', count: count, sum: null };
  }, [selection, rowData]);
  
  return {
    tableContainerRef,
    selection,
    isSelecting,
    selectionStats,
    frozenColumns,
    columns,
    handleMouseDown,
    handleMouseEnter,
    handleMouseUp,
    isCellSelected,
    getStickyStyles,
  };
}
