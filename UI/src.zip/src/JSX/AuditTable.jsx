import React from 'react';
import {
  useReactTable,
  getCoreRowModel,
  flexRender,
} from '@tanstack/react-table';
import { useVirtualizer } from '@tanstack/react-virtual';
import { DARK_THEME, useAuditTable } from '../JS/Utilities.js';

function AuditTable({ rowData, isLoading }) {
  const {
    tableContainerRef,
    frozenColumns,
    columns,
    handleMouseDown,
    handleMouseEnter,
    handleMouseUp,
    isCellSelected,
    getStickyStyles,
  } = useAuditTable(rowData);

  const table = useReactTable({
    data: rowData,
    columns,
    getCoreRowModel: getCoreRowModel(),
    columnResizeMode: 'onChange',
  });

  const { rows } = table.getRowModel();

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 35,
    overscan: 10,
  });

  if (isLoading) return <div style={{ color: 'white', padding: '20px', textAlign: 'right' }}>טוען דוח...</div>;
  if (!rowData || rowData.length === 0) return <div style={{ color: 'white', textAlign: 'center', padding: '50px' }}>אין נתונים להצגה</div>;

  return (
    <div
      ref={tableContainerRef}
      className="audit-table-container"
      onMouseUp={handleMouseUp}
      style={{
        height: '100%',
        width: '100%',
        overflow: 'auto',
        background: DARK_THEME.pageBg,
        direction: 'rtl',
      }}
    >
      <table style={{ display: 'grid', width: 'fit-content', borderCollapse: 'collapse' }}>
        <thead style={{ display: 'grid', position: 'sticky', top: 0, zIndex: 4, background: DARK_THEME.headerBg }}>
          {table.getHeaderGroups().map(headerGroup => (
            <tr key={headerGroup.id} style={{ display: 'flex', width: '100%' }}>
              {headerGroup.headers.map(header => (
                <th
                  key={header.id}
                  style={{
                    width: header.getSize(),
                    padding: '8px 12px',
                    color: DARK_THEME.headerText,
                    border: `1px solid ${DARK_THEME.border}`,
                    textAlign: 'right',
                    position: 'relative',
                    userSelect: 'none',
                    ...getStickyStyles(header.id, true),
                  }}
                >
                  {flexRender(header.column.columnDef.header, header.getContext())}
                  <div
                    onMouseDown={header.getResizeHandler()}
                    className="resizer"
                    style={{
                      position: 'absolute',
                      left: 0, top: 0, height: '100%', width: '4px',
                      cursor: 'col-resize',
                      background: header.column.getIsResizing() ? DARK_THEME.accent : 'transparent',
                    }}
                  />
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody style={{ display: 'grid', height: `${rowVirtualizer.getTotalSize()}px`, position: 'relative' }}>
          {rowVirtualizer.getVirtualItems().map(virtualRow => {
            const row = rows[virtualRow.index];
            return (
              <tr
                key={row.id}
                style={{
                  display: 'flex',
                  position: 'absolute',
                  transform: `translateY(${virtualRow.start}px)`,
                  width: '100%',
                  height: `${virtualRow.size}px`,
                }}
              >
                {row.getVisibleCells().map((cell, colIndex) => {
                  const selected = isCellSelected(virtualRow.index, colIndex);
                  return (
                    <td
                      key={cell.id}
                      onMouseDown={() => handleMouseDown(virtualRow.index, colIndex)}
                      onMouseEnter={() => handleMouseEnter(virtualRow.index, colIndex)}
                      style={{
                        width: cell.column.getSize(),
                        padding: '4px 12px',
                        color: DARK_THEME.text,
                        background: selected
                          ? DARK_THEME.selection
                          : frozenColumns.includes(cell.column.id)
                            ? DARK_THEME.cellBg
                            : 'transparent',
                        border: `1px solid ${selected ? DARK_THEME.accent : DARK_THEME.border}`,
                        textAlign: 'right',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        cursor: 'cell',
                        userSelect: 'none',
                        ...getStickyStyles(cell.column.id, false),
                      }}
                    >
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default AuditTable;
