import React from 'react';
import { DARK_THEME } from '../JS/Utilities.js';

function TopBar({ metadata }) {
  return (
    <header style={{
        width: 'auto',
        padding: '1rem 2rem',
        borderBottom: `1px solid ${DARK_THEME.border}`,
        backgroundColor: DARK_THEME.pageBg,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '4px'
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '15px' }}>
        <h1 style={{ 
          color: '#ffffff', 
          margin: 0, 
          fontSize: '1.5rem', 
          fontWeight: '600' 
        }}>
          {metadata.companyName || "מערכת בדיקת שכר"}
        </h1>
        
        <span style={{ 
          color: DARK_THEME.headerText, 
          fontSize: '0.9rem',
          fontFamily: 'monospace'
        }}>
          {metadata.dateRange}
        </span>
      </div>

      <div style={{ 
        color: DARK_THEME.accent, 
        fontSize: '0.85rem', 
        fontWeight: '500',
        opacity: 0.9
      }}>
        {metadata.reportTitle}
      </div>
    </header>
  );
}

export default TopBar;