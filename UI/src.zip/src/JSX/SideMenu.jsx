import React from 'react';
import '../CSS/SideMenuDropdown.css';
import templateIcon from '../assets/icon-template-fill.png';
import paqaLogo from '../assets/verisal-logo2.svg';
import helpIcon from '../assets/icon-help-fill.png';
import fileIcon from '../assets/icon-file-fill.png';
import content from '../JSON/strings.json';
import { useSideMenu } from '../JS/Utilities.js';
import { ActionButton } from './SideMenuActionButton.jsx';
import { SideMenuDropdown } from './sideMenuDropdown.jsx';

function SideMenu({ setTableData, setIsLoading, setMetadata }) {
  const {
    sharedSelectedItem,
    openDropdown,
    toggleDropdown,
    handleSelect,
  } = useSideMenu(setTableData, setIsLoading, setMetadata);

  return (
    <aside className="sidebar">
      <div className="logo">
        <img src={paqaLogo} alt="PAQA Logo" style={{ width: '150px', height: 'auto', marginBottom: '10px' }} />
      </div>

      <div className="sidebar-all-dropdowns">
        <SideMenuDropdown
          title={content.sideMenuSourceReportDropdownHeader}
          icon={fileIcon}
          items={content.sideMenuSourceReportDropdownNames}
          globalSelected={sharedSelectedItem}
          onSelect={(itemData) => handleSelect(content.sideMenuSourceReportDropdownHeader, itemData)}
          isOpen={openDropdown === content.sideMenuSourceReportDropdownHeader}
          onToggle={() => toggleDropdown(content.sideMenuSourceReportDropdownHeader)}
        />

        <SideMenuDropdown
          title={content.sideMenuTemplatesDropdownHeader}
          icon={templateIcon}
          items={content.templatesNames}
          globalSelected={sharedSelectedItem}
          onSelect={(itemData) => handleSelect(content.sideMenuTemplatesDropdownHeader, itemData)}
          isOpen={openDropdown === content.sideMenuTemplatesDropdownHeader}
          onToggle={() => toggleDropdown(content.sideMenuTemplatesDropdownHeader)}
        />
      </div>

      <ActionButton
        style={{ marginBottom: '1.25rem', marginTop: 'auto' }}
        icon={helpIcon}
        label={content.sideMenuHelpButtonTitle}
        onClick={() => console.log('Help Clicked')}
      />
    </aside>
  );
}

export { SideMenu };