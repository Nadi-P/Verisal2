import React from 'react';
import { SideMenu } from './SideMenu.jsx';
import AuditTable from './AuditTable.jsx';
import TopBar from './TopStatusBar.jsx';
import { useAppState } from '../JS/Utilities.js';

function App() {
  const { rowData, setRowData, isLoading, setIsLoading, metadata, setMetadata } = useAppState();

  return (
    <div className="app-container" style={{ display: 'flex', height: '100vh', direction: 'rtl' }}>
      <main className="main-content" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow:'auto' }}>
        <TopBar metadata={metadata} />
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <AuditTable rowData={rowData} isLoading={isLoading} />
        </div>
      </main>
      <SideMenu 
        setTableData={setRowData} 
        setIsLoading={setIsLoading} 
        setMetadata={setMetadata} 
      />
    </div>
  );
}

export default App;